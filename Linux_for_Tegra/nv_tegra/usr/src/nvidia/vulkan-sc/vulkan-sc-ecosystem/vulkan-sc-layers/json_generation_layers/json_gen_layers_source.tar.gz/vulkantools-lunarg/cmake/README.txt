The following files are copied out of CMake 2.8.
- FindImageMagick.cmake

I have also copied the Copyright.txt file out of cmake and renamed it:
- Copyright_cmake.txt

All other files are created and/or maintained by either LunarG Inc or Valve Corporation.