The svg image files in this folder were created using Inkscape 1.0.1 and
are all copyrighted by Valve Corporation and LunarG, Inc under the
Apache 2.0 license (as define in the top LICENSE.txt file of this repo).

For updating, simply load into Inkscape, modify, and save the resulting
images to the folder above this one.
