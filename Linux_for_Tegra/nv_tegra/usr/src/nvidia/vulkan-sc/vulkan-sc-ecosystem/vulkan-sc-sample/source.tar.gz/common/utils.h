#ifndef  UTIL_H
#define  UTIL_H

#ifdef VULKANSC

#include <vulkan/vulkan_sc_core.hpp>
#include <fstream>

static VkResult readPipelineUUID(std::string fileName, char UUID[VK_UUID_SIZE])
{
    VkResult err;
    std::string readFileName(fileName);
    std::cout << "  Trying to read pipeline UUID from: " << readFileName << std::endl;
    FILE* pReadFile = fopen(fileName.c_str(), "rb");

    if (pReadFile) {
        fseek(pReadFile, 0, SEEK_END);
        size_t fileSize = ftell(pReadFile);
        rewind(pReadFile);

        char* buffer = (char*)malloc(sizeof(char) * fileSize);
        if (buffer == nullptr) {
            fputs("Memory error", stderr);
            exit(EXIT_FAILURE);
        }

        size_t result = fread(buffer, sizeof(char), fileSize, pReadFile);
        if (result != fileSize) {
            fputs("Reading error", stderr);
            free(buffer);
            exit(EXIT_FAILURE);
        }

        size_t index = 0;
        char* p = strstr(buffer, "PipelineUUID");
        if (p != NULL) {
            err = VK_SUCCESS;
            while (*p && index < VK_UUID_SIZE) {
                if (isdigit(*p)) {
                    UUID[index++] = (char)strtol(p, &p, 10);
                } else {
                    p++;
                }
            }
        }

        free(buffer);
        fclose(pReadFile);
    } else {
        std::cout << "Error reading json file" << std::endl;
    }

    return err;
}
#endif // #ifdef VULKANSC
#endif // #ifndef UTIL_H
