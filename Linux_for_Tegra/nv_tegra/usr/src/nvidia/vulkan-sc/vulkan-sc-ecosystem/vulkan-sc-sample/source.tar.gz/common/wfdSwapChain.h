#ifndef WFD_SWAP_CHAIN_H
#define WFD_SWAP_CHAIN_H

#include "wfd_nvsci.h"
#include <vulkan/vulkan_sc_core.hpp>
#include <vulkan/vulkan_sci.h>
#include <array>
#include <tuple>

class SwapChainWfd {
public:
    SwapChainWfd() {}

    VkResult Init(VkInstance instance, VkPhysicalDevice physDevice, VkDevice dev,
                  const uint32_t width, const uint32_t height);

    ~SwapChainWfd();

    // Get front buffer for rendering
    // completePresentSemaphore Semaphore that is signaled when image is ready to render.
    //                          queueSubmit must wait this semaphore.
    void GetNexImage(uint32_t* currentBufferIdx, VkSemaphore* pCompletePresentSemaphore);

    // Flip back buffer to display
    // completeRenderSemaphore Semaphore that is waited when image is ready to represent.
    //                         wfd must wait this semaphore before flip.
    void PresentImage(VkSemaphore* pCompleteRenderSemaphore);

    void GetSwapChainImages(VkImage* images, size_t imageCount);

    // Create VkImage and bind VkDeviceMemory that is imported from NvSciBufObj
    // void Create(const uint32_t width, const uint32_t height);

    static constexpr uint32_t                IMAGE_COUNT = 2;
private:
    void CreateImages(VkImage* images);
    void InitWFD();
    VkResult InitNvSciBufModule();
    bool LoadSymbols();
    VkResult SetupNvSciBufVkDeviceMemory(VkImageCreateInfo imageInfo, VkMemoryRequirements memReqs);
    VkResult getAttrListFromVkImage(const VkImageCreateInfo& imageInfo, const VkMemoryRequirements& memReqs, NvSciBufAttrList attrList);

    uint32_t                                 m_currentImageIdx {0};
    std::array<NvSciBufObj,     IMAGE_COUNT> m_nvsciBufObjs;
    std::array<VkDeviceMemory,  IMAGE_COUNT> m_imageMems;
    uint32_t                                 m_width;
    uint32_t                                 m_height;

    WFDResources                             m_wfdRes;

    VkSemaphore completeRenderSemaphore {VK_NULL_HANDLE};
    VkSemaphore completePresentSemaphore {VK_NULL_HANDLE};
    NvSciBufModule  sciBufModule {nullptr};
    NvSciSyncModule sciSyncModule {nullptr};

    VkInstance          m_instance {VK_NULL_HANDLE};
    VkPhysicalDevice    m_physDevice {VK_NULL_HANDLE};
    VkDevice            m_device {VK_NULL_HANDLE};
    PFN_vkGetDeviceProcAddr                     fpGetDeviceProcAddr {nullptr};
    PFN_vkGetPhysicalDeviceSciBufAttributesNV   fpGetPhysicalDeviceSciBufAttributesNV {nullptr};
    PFN_vkGetMemorySciBufNV                     fpGetMemorySciBufNV {nullptr};

};

#endif //#ifndef WFD_SWAP_CHAIN_H
