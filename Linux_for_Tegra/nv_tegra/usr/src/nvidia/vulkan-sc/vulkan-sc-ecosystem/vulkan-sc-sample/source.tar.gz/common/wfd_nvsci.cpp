/*
 * Copyright (c) 2021 NVIDIA Corporation. All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

#include "wfd_nvsci.h"

// Function pointer typedef for the subtests
typedef bool TestFunction(void);

uint32_t imageWidth = 640U;
uint32_t imageHeight = 480U;
static const uint32_t imagePlaneCount = 1U;
static const uint32_t semiPlanarImageCount = 2U;
static const uint32_t planarImageCount = 3U;
static const uint32_t numFrames = 120U; // Number of frames to display
static const uint32_t pitchAlignment = 256U; // Taken from NVRM_SURFACE_LINEAR_PITCH_ALIGN
static const uint32_t numTests = 6U; // Update this when new tests are added

void DebugNvSciBufAttrDump(NvSciBufAttrList attrList)
{
    NvSciBufAttrKeyValuePair bufAttrs[] = {
        { NvSciBufGeneralAttrKey_RequiredPerm,   nullptr, 0  },
        { NvSciBufGeneralAttrKey_Types,          nullptr, 0  },
        { NvSciBufGeneralAttrKey_NeedCpuAccess,  nullptr, 0  },
        { NvSciBufImageAttrKey_Layout,           nullptr, 0  },
        { NvSciBufImageAttrKey_PlaneCount,       nullptr, 0  },
        { NvSciBufImageAttrKey_PlaneColorFormat, nullptr, 0  },
        { NvSciBufImageAttrKey_PlaneColorStd,    nullptr, 0  },
        { NvSciBufImageAttrKey_PlaneWidth,       nullptr, 0  },
        { NvSciBufImageAttrKey_PlaneHeight,      nullptr, 0  },
        { NvSciBufImageAttrKey_ScanType,         nullptr, 0  },
    };
    uint32_t count = sizeof(bufAttrs) / sizeof(NvSciBufAttrKeyValuePair);
    NvSciBufAttrListGetAttrs(attrList, bufAttrs, count);
    printf("key = %d, val = %d\n", NvSciBufGeneralAttrKey_RequiredPerm, *static_cast<const NvSciBufAttrValAccessPerm*>(bufAttrs[0].value));
    printf("key = %d, val = %d\n", NvSciBufGeneralAttrKey_Types, *static_cast<const NvSciBufType*>(bufAttrs[1].value));
    printf("key = %d, val = %d\n", NvSciBufGeneralAttrKey_NeedCpuAccess, *static_cast<const bool*>(bufAttrs[2].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_Layout, *static_cast<const NvSciBufAttrValImageLayoutType*>(bufAttrs[3].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_PlaneCount, *static_cast<const uint32_t*>(bufAttrs[4].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_PlaneColorFormat, *static_cast<const NvSciBufAttrValColorFmt*>(bufAttrs[5].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_PlaneColorStd, *static_cast<const NvSciBufAttrValColorStd*>(bufAttrs[6].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_PlaneWidth, *static_cast<const uint32_t*>(bufAttrs[7].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_PlaneHeight, *static_cast<const uint32_t*>(bufAttrs[8].value));
    printf("key = %d, val = %d\n", NvSciBufImageAttrKey_ScanType, *static_cast<const NvSciBufAttrValImageScanType*>(bufAttrs[9].value));

}


bool WFDResources::InitializeRGB(uint32_t width, uint32_t height, NvSciBufAttrList unreconciledList, NvSciBufAttrValImageLayoutType imageLayout)
{
    NvSciError err = NvSciError_Success;
    // Default buffer attributes
    NvSciBufType bufType = NvSciBufType_Image;
    NvSciBufAttrValImageLayoutType layout = imageLayout;
    NvSciBufAttrValColorFmt bufColorFormat = NvSciColor_A8R8G8B8;
    NvSciBufAttrValColorStd bufColorStd = NvSciColorStd_SRGB;
    NvSciBufAttrValImageScanType bufScanType = NvSciBufScan_ProgressiveType;
    NvSciBufAttrValAccessPerm bufPerm = NvSciBufAccessPerm_ReadWrite;

    NvSciBufAttrKeyValuePair pairArray[] = {
        { NvSciBufGeneralAttrKey_RequiredPerm,   &bufPerm,           sizeof(bufPerm) },
        { NvSciBufGeneralAttrKey_Types,          &bufType,           sizeof(bufType) },
        { NvSciBufImageAttrKey_Layout,           &layout,            sizeof(layout) },
        { NvSciBufImageAttrKey_PlaneCount,       &imagePlaneCount,   sizeof(imagePlaneCount) },
        { NvSciBufImageAttrKey_PlaneColorFormat, &bufColorFormat,    sizeof(bufColorFormat) },
        { NvSciBufImageAttrKey_PlaneColorStd,    &bufColorStd,       sizeof(bufColorStd) },
        { NvSciBufImageAttrKey_PlaneWidth,       &width,             sizeof(width) },
        { NvSciBufImageAttrKey_PlaneHeight,      &height,            sizeof(height) },
        { NvSciBufImageAttrKey_ScanType,         &bufScanType,       sizeof(bufScanType) },
    };

    err = NvSciBufAttrListSetAttrs(unreconciledList, pairArray,
                                   sizeof(pairArray)/sizeof(NvSciBufAttrKeyValuePair));
    if (err != NvSciError_Success) {
        std::cerr << "Failed to set attribute list to the specified attributes" << std::endl;
        return false;
    }

    // set private attributes by openwfd
    WFDErrorCode errcode = wfdNvSciBufSetDisplayAttributesNVX(&unreconciledList);
    if (errcode) {
        std::cerr << "Failed to set Display attributes for NvSciBufObj\n";
        return false;
    }
    return true;
}


bool WFDResources::WfdInit(uint32_t widthToUse, uint32_t heightToUse)
{
    device = wfdCreateDevice(WFD_DEFAULT_DEVICE_ID, NULL);
    if (!device) {
        std::cerr << "Failed to create WFDDevice handle. Check slog2info for any errors." << std::endl;
        inited = false;
        return inited;
    }

    numPorts = wfdEnumeratePorts(device, &portId, 1, NULL);
    if (!numPorts) {
        CHECK_WFD_ERROR(device);
        std::cerr << "No WFDPorts found " << std::endl;
        inited = false;
        return inited;
    }

    port = wfdCreatePort(device, portId, NULL);
    if (!port) {
        CHECK_WFD_ERROR(device);
        std::cerr << "Failed to create WFDPort for Port ID " << portId << std::endl;
        inited = false;
        return inited;
    }

    numModes = wfdGetPortModes(device, port, &portMode, 1);
    if (!numModes) {
        CHECK_WFD_ERROR(device);
        std::cerr << "Failed to get PortModes for WFDPort ID " << portId << std::endl;
        inited = false;
        return inited;
    }

    wfdSetPortMode(device, port, portMode);
    CHECK_WFD_ERROR(device);

    wfdDeviceCommit(device, WFD_COMMIT_ENTIRE_PORT, port);
    CHECK_WFD_ERROR(device);

    numPorts = wfdEnumeratePipelines(device, &pipeId, 1, NULL);
    if (!numPorts) {
        CHECK_WFD_ERROR(device);
        std::cerr << "Failed to enumerate Pipelines" << std::endl;
        inited = false;
        return inited;
    }

    pipe = wfdCreatePipeline(device, pipeId, NULL);
    if (!pipe) {
        CHECK_WFD_ERROR(device);
        std::cerr << "Failed to create pipeline" << std::endl;
        inited = false;
        return inited;
    }

    wfdBindPipelineToPort(device, port, pipe);
    CHECK_WFD_ERROR(device);

    wfdDeviceCommit(device, WFD_COMMIT_ENTIRE_PORT, port);
    CHECK_WFD_ERROR(device);

    sourceRect[2] = widthToUse;
    sourceRect[3] = heightToUse;
    inited = true;
    return inited;
}

bool WFDResources::BindNvSciBufObj(NvSciBufObj* scibufobj, size_t sciBufObjCount)
{
    for (size_t i = 0; i < sciBufObjCount; i++) {
        WFDSource source = wfdCreateSourceFromNvSciBufNVX(device, pipe, &scibufobj[i]);
        if (!source) {
            CHECK_WFD_ERROR(device);
            std::cerr << "Failed to create WFDSource" << std::endl;
            return false;
        }
        sources.push_back(source);
        printf("bind souce %lu to scibuf %p\n", sources.size() - 1, *scibufobj);
    }

    return true;
}

void WFDResources::FlipSubmit(uint32_t bufferIdx)
{
    if (sources.size() <= bufferIdx) {
        CHECK_WFD_ERROR(device);
        std::cerr << "FlipSubmit:Out of bound" << std::endl;
        return;
    }
    wfdBindSourceToPipeline(device, pipe, sources[bufferIdx], WFD_TRANSITION_AT_VSYNC, NULL);
    CHECK_WFD_ERROR(device);

    wfdSetPipelineAttribiv(device, pipe, WFD_PIPELINE_SOURCE_RECTANGLE, 4, sourceRect);
    CHECK_WFD_ERROR(device);

    wfdSetPipelineAttribiv(device, pipe, WFD_PIPELINE_DESTINATION_RECTANGLE, 4, sourceRect);
    CHECK_WFD_ERROR(device);

    wfdDeviceCommit(device, WFD_COMMIT_PIPELINE, pipe);
    CHECK_WFD_ERROR(device);
}
