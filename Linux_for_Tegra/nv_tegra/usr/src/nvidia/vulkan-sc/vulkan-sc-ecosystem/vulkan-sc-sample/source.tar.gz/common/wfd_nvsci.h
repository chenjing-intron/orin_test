/*
 * Copyright (c) 2021 NVIDIA Corporation. All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 */

#include <iostream>
#include <thread>
#include <cstring>
#include <vector>
// The extension string for WFD_NVX_create_source_from_nvscibuf
// need to be defined before including the WFD headers
#define WFD_NVX_create_source_from_nvscibuf
#define WFD_WFDEXT_PROTOTYPES
#include <WF/wfd.h>
#include <WF/wfdext.h>

#include "nvscibuf.h"
// #include "nvscibuf_internal.h"
#include "nvscisync.h"
// #include "nvrm_surface.h"

// Helper macro for WFD Error checking
#define CHECK_WFD_ERROR(device)                                             \
    {                                                                       \
        WFDErrorCode wfdErr = wfdGetError(device);                          \
        if (wfdErr) {                                                       \
            std::cerr << "WFD Error 0x" << std::hex << wfdErr << " at: " << \
                                        std::dec << std::endl;              \
            std::cerr << __FILE__ << ":" << __LINE__ << std::endl;          \
        };                                                                  \
    }

void DebugNvSciBufAttrDump(NvSciBufAttrList attrList);

struct WFDResources
{
    WFDDevice device {WFD_INVALID_HANDLE};
    WFDint numPorts {0};
    WFDint numPipes {0};
    WFDint numModes {0};
    WFDint portId {WFD_INVALID_PORT_ID};
    WFDint pipeId {WFD_INVALID_PIPELINE_ID};
    WFDPort port {WFD_INVALID_HANDLE};
    WFDPipeline pipe {WFD_INVALID_HANDLE};
    WFDPortMode portMode {WFD_INVALID_HANDLE};
    std::vector<WFDSource> sources;
    WFDint sourceRect[4] {0, 0, 0, 0};
    NvSciBufObj *bufObj {nullptr};
    bool inited {false};

    WFDResources() {}
    bool WfdInit(uint32_t widthToUse, uint32_t heightToUse);
    bool BindNvSciBufObj(NvSciBufObj* scibufobjs, size_t sciBufObjCount);
    void FlipSubmit(uint32_t bufferIdx);

    static bool InitializeRGB(uint32_t width, uint32_t height, NvSciBufAttrList unreconciledList, NvSciBufAttrValImageLayoutType imageLayout);

    ~WFDResources()
    {
        if (device && pipe) {
            // Perform a null flip
            wfdBindSourceToPipeline(device, pipe, (WFDSource)0, WFD_TRANSITION_AT_VSYNC, NULL);
            wfdDeviceCommit(device, WFD_COMMIT_PIPELINE, pipe);
        }

        for (uint32_t i = 0; i < sources.size() ; i++) {
            if (sources[i]) {
                wfdDestroySource(device, sources[i]);
            }
        }

        if (pipe) {
            wfdDestroyPipeline(device, pipe);
        }

        if (port) {
            wfdDestroyPort(device, port);
        }

        if (device) {
            wfdDestroyDevice(device);
        }
    }
};
